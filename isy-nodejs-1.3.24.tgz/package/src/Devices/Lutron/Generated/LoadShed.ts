/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import { Lutron } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = LoadShed.Commands.Type;
type Drivers = LoadShed.Drivers.Type;
type Events = LoadShed.Events.Type;

export class LoadShed extends Base<Drivers, Commands, Events> implements LoadShed.Interface {
	public override readonly commands = {
		DON: this.on,
		DOF: this.off,
		QUERY: this.query
	};
	static override nodeDefId = "LUTLoadShed";
	static override implements = ['LUTLoadShed'];
	declare readonly nodeDefId: 'LUTLoadShed';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.Lutron>) {
		super(isy, nodeInfo);
		this.drivers.ST = Driver.create("ST", this, nodeInfo.state['ST'], { uom: UnitOfMeasure.Percent, label: "Status", name: "status" });
		this.drivers.ERR = Driver.create("ERR", this, nodeInfo.state['ERR'], { uom: UnitOfMeasure.Index, label: "Responding", name: "responding" });
	}
	async on(value?: (0 | 100)) { return this.sendCommand("DON", [value, UnitOfMeasure.Percent]); }
	async off() { return this.sendCommand("DOF"); }
	async query() { return this.sendCommand("QUERY"); }
	public get status(): (0 | 100) {
		return this.drivers.ST?.value;
	}
	public get responding(): Lutron.Error {
		return this.drivers.ERR?.value;
	}
}

NodeFactory.register(LoadShed);

export namespace LoadShed {
	export interface Interface extends Omit<InstanceType<typeof LoadShed>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is LoadShed {
		return ['LUTLoadShed'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is LoadShed {
		return ['LUTLoadShed'].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.Lutron>) {
		return new LoadShed(isy, nodeInfo);
	}
	export const Node = LoadShed;
	export const Class = LoadShed;
	export namespace Commands {
		export type Type = {
			DON: ((value?: (0 | 100)) => Promise<boolean>) & {
				label: "On";
				name: "on";
			};
			DOF: (() => Promise<boolean>) & {
				label: "Off";
				name: "off";
			};
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
		};
	}
	export enum Commands {
		on = 'DON',
		off = 'DOF',
		query = 'QUERY'
	}
	export namespace Drivers {
		export type Type = {
			ST: {
				uom: UnitOfMeasure.Percent;
				value: (0 | 100);
				label: "Status";
				name: "status";
			};
			ERR: {
				uom: UnitOfMeasure.Index;
				value: Lutron.Error;
				label: "Responding";
				name: "responding";
			};
		};
	}
	export enum Drivers {
		status = 'ST',
		responding = 'ERR'
	}
	export namespace Events {
		export type Type = {};
	}
	export enum Events {
	}
}
