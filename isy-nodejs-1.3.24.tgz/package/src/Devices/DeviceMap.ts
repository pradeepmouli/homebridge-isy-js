import { Category } from '../Definitions/Global/Categories.js';
import { Family } from '../Definitions/Global/Families.js';
import type { Feature } from '../Definitions/Global/Features.js';
import type { PickOfType } from '../Utils.js';
import type * as Devices from './index.js';

// tslint:disable-next-line: no-unused-expression
// tslint:disable-next-line: no-angle-bracket-type-assertion

//type s<T extends Family> = ISYDevice<T, any, any, any>;

//type DeviceNames<T extends Family> = `${T extends Family.Insteon | Family.ZWave | Family.ZigBee ? StringKeyOf< : never}`;
//type x = DeviceNames<Family.Insteon>;

type LabelFor<T extends number> = T extends Family.Insteon | Family.ZWave | Family.ZigBee
	? PickOfType<typeof Family, T>
	: never;

export interface DeviceDef<T> {
	id: number;
	type?: string;
	name: string;
	modelNumber?: string;
	//@ts-ignore
	class?: keyof (typeof Devices)[LabelFor<T>];
	features?: Feature;
}

export interface CategoryDef<T extends Family, C extends Category.Insteon> {
	id: C;
	name: string;
	devices: { [x: number]: DeviceDef<T> };
}

export interface FamilyDef<T extends Family> {
	id: T;
	name: string;
	description: string;

	manufacturer?: string;
	categories: { [key in keyof typeof Category.Insteon]?: CategoryDef<T, (typeof Category.Insteon)[key]> };
}

/*var s : FamilyDef<Family.Insteon> = { id: Family.Insteon, description: "Insteon", name: "Insteon", categories: {DimmableControl: {id: Category.Insteon.DimmableControl, name: "DimmableControl", devices: {1:{id: 0, name: "DimmableControl"}}}}};*/

export type DeviceMap = {
	[key in keyof typeof Family]?: FamilyDef<(typeof Family)[key]> & { name: key };
};

/*export function register(deviceMap: DeviceMap) {
	for (const key in deviceMap) {
		const element = deviceMap[key];
		for (const catKey in element.categories) {
			for (const devKey in element.categories[catKey].devices) {
				const dev = element.categories[catKey].devices[devKey];
				const device = Devices[key][dev.class as string];
				if (device) {
					device.typeCodes.push(dev.type ?? dev.name);
				}
			}
		}
	}
}*/
