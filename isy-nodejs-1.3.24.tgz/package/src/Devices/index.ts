import { type Family } from '../Definitions/index.js';
import * as Insteon from './Insteon/index.js';
import { NodeFactory } from './NodeFactory.js';
import * as ZWave from './ZWave/index.js';
import * as ZigBee from './ZigBee/index.js';

export * as Insteon from './Insteon/index.js';
export * as ZWave from './ZWave/index.js';
export * as ZigBee from './ZigBee/index.js';

export type OfFamily<T extends Family.Insteon | Family.ZWave | Family.ZigBee> = T extends Family.Insteon
	? typeof Insteon
	: T extends Family.ZWave
		? typeof ZWave
		: T extends Family.ZigBee
			? typeof ZigBee
			: never;
/*export type ToDevice<T extends keyof Devices<any>> = T extends keyof Devices<infer B> ? Devices<B>[`${T}`] : never;*/

NodeFactory.sortImplementsRegistry();
