import 'winston';
import { Family } from '../../Definitions/Global/Families.js';
import { logStringify } from '../../ISY.js';
import { ISYNode } from '../../ISYNode.js';
import type { NodeDef } from '../../Model/NodeDef.js';
import { byteToDegree, byteToPct, pctToByte } from '../../Utils.js';
import { DynamicNode } from '../DynamicNode.js';

// import { InsteonNLS } from './insteonfam'
export abstract class ZWaveBase<
	D extends ISYNode.DriverSignatures,
	C extends ISYNode.CommandSignatures,
	E extends ISYNode.EventSignatures = {},
> extends DynamicNode<Family.ZWave, D, C, E> {
	static override family: Family.ZWave = Family.ZWave;

	public async getNodeDef(nodeDefId: string): Promise<NodeDef> {
		let n = (
			await this.isy.sendRequest<{ nodeDefs: { nodeDef: NodeDef } }>(
				`zmatter/zwave/node/${this.address}/def/get?full=true`,
				{ trailingSlash: false }
			)
		).nodeDefs.nodeDef;
		this.logger(`Node is ZWave. NodeDef: ${logStringify(n)}`);
		return n;
	}

	public override convertFrom(value: any, uom: number): any {
		switch (uom) {
			case 101:
				return byteToDegree(value);
			case 100:
				return byteToPct(value);
			case 17:
				return value / 10;
			default:
				return super.convertFrom(value, uom);
		}
	}
	public override convertTo(value: any, uom: number): any {
		const nuom = super.convertTo(value, uom);
		switch (uom) {
			case 101:
				return nuom * 2;
			case 100:
				return pctToByte(nuom);
			case 17:
				return Math.round(value * 10);
			default:
				return nuom;
		}
	}
}
