/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = CentralSceneControlButton.Commands.Type;
type Drivers = CentralSceneControlButton.Drivers.Type;
type Events = CentralSceneControlButton.Events.Type;

export class CentralSceneControlButton extends Base<Drivers, Commands, Events> implements CentralSceneControlButton.Interface {
	public override readonly commands = {
		QUERY: this.query
	};

	static override nodeDefId = "201";
	static override implements = ['201'];
	declare readonly nodeDefId: '201';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		super(isy, nodeInfo);
		this.drivers.ST = Driver.create("ST", this, nodeInfo.state['ST'], { uom: UnitOfMeasure.MostRecentOnStyleActionTakenForLampControl, label: "Status", name: "status" });
	}
	async query() { return this.sendCommand("QUERY"); }
	public get status(): number {
		return this.drivers.ST?.value;
	}
}

NodeFactory.register(CentralSceneControlButton);

export namespace CentralSceneControlButton {
	export interface Interface extends Omit<InstanceType<typeof CentralSceneControlButton>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is CentralSceneControlButton {
		return ['201'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is CentralSceneControlButton {
		return ['201'].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		return new CentralSceneControlButton(isy, nodeInfo);
	}
	export const Node = CentralSceneControlButton;
	export const Class = CentralSceneControlButton;
	export namespace Commands {
		export type Type = {
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
		};
	}
	export enum Commands {
		query = 'QUERY'
	}
	export namespace Drivers {
		export type Type = {
			ST: {
				uom: UnitOfMeasure.MostRecentOnStyleActionTakenForLampControl;
				value: number;
				label: "Status";
				name: "status";
			};
		};
	}
	export enum Drivers {
		status = 'ST'
	}
	export namespace Events {
		export type Type = {
			DON: {
				label: "On";
				name: "on";
			};
			FDSTOP: {
				label: "Fade Stop";
				name: "fadeStop";
			};
			FDUP: {
				label: "Fade Up";
				name: "fadeUp";
			};
			DFON: {
				label: "Fast On";
				name: "fastOn";
			};
			DON3: {
				label: "Triple Press (On)";
				name: "triplePressOn";
			};
			DON4: {
				label: "4 x Press (On)";
				name: "4XPressOn";
			};
			DON5: {
				label: "5 x Press (On)";
				name: "5XPressOn";
			};
		};
	}
	export enum Events {
		on = 'DON',
		fadeStop = 'FDSTOP',
		fadeUp = 'FDUP',
		fastOn = 'DFON',
		triplePressOn = 'DON3',
		'4XPressOn' = 'DON4',
		'5XPressOn' = 'DON5'
	}
}
