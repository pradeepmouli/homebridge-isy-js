/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = SceneResponder.Commands.Type;
type Drivers = SceneResponder.Drivers.Type;
type Events = SceneResponder.Events.Type;

export class SceneResponder extends Base<Drivers, Commands, Events> implements SceneResponder.Interface {
	public override readonly commands = {
		QUERY: this.query
	};

	static override nodeDefId = "259";
	static override implements = ['259'];
	declare readonly nodeDefId: '259';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		super(isy, nodeInfo);
	}
	async query() { return this.sendCommand("QUERY"); }
}

NodeFactory.register(SceneResponder);

export namespace SceneResponder {
	export interface Interface extends Omit<InstanceType<typeof SceneResponder>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is SceneResponder {
		return ['259'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is SceneResponder {
		return ['259', "111", "137", "147", "201", "252", "306", "309"].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		return new SceneResponder(isy, nodeInfo);
	}
	export const Node = SceneResponder;
	export const Class = SceneResponder;
	export namespace Commands {
		export type Type = {
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
		};
	}
	export enum Commands {
		query = 'QUERY'
	}
	export namespace Drivers {
		export type Type = {};
	}
	export enum Drivers {
	}
	export namespace Events {
		export type Type = {};
	}
	export enum Events {
	}
}
