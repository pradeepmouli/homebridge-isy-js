/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import { ZWave } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = PowerManagementAlarm.Commands.Type;
type Drivers = PowerManagementAlarm.Drivers.Type;
type Events = PowerManagementAlarm.Events.Type;

export class PowerManagementAlarm extends Base<Drivers, Commands, Events> implements PowerManagementAlarm.Interface {
	public override readonly commands = {
		QUERY: this.query
	};

	static override nodeDefId = "309";
	static override implements = ['309', "259"];
	declare readonly nodeDefId: '309';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		super(isy, nodeInfo);
		this.drivers.ALARM = Driver.create("ALARM", this, nodeInfo.state['ALARM'], { uom: UnitOfMeasure.Index, label: "Power Management", name: "powerManagement" });
	}
	async query() { return this.sendCommand("QUERY"); }
	public get powerManagement(): ZWave.AlertPm {
		return this.drivers.ALARM?.value;
	}
}

NodeFactory.register(PowerManagementAlarm);

export namespace PowerManagementAlarm {
	export interface Interface extends Omit<InstanceType<typeof PowerManagementAlarm>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is PowerManagementAlarm {
		return ['309'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is PowerManagementAlarm {
		return ['309', "306"].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		return new PowerManagementAlarm(isy, nodeInfo);
	}
	export const Node = PowerManagementAlarm;
	export const Class = PowerManagementAlarm;
	export namespace Commands {
		export type Type = {
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
		};
	}
	export enum Commands {
		query = 'QUERY'
	}
	export namespace Drivers {
		export type Type = {
			ALARM: {
				uom: UnitOfMeasure.Index;
				value: ZWave.AlertPm;
				label: "Power Management";
				name: "powerManagement";
			};
		};
	}
	export enum Drivers {
		powerManagement = 'ALARM'
	}
	export namespace Events {
		export type Type = {};
	}
	export enum Events {
	}
}
