/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = BasicAssociation.Commands.Type;
type Drivers = BasicAssociation.Drivers.Type;
type Events = BasicAssociation.Events.Type;

export class BasicAssociation extends Base<Drivers, Commands, Events> implements BasicAssociation.Interface {
	public override readonly commands = {
		QUERY: this.query
	};
	static override nodeDefId = "252";
	static override implements = ['252', "259"];
	declare readonly nodeDefId: '252';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		super(isy, nodeInfo);
	}
	async query() { return this.sendCommand("QUERY"); }
}

NodeFactory.register(BasicAssociation);

export namespace BasicAssociation {
	export interface Interface extends Omit<InstanceType<typeof BasicAssociation>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is BasicAssociation {
		return ['252'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is BasicAssociation {
		return ['252', "137", "147"].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		return new BasicAssociation(isy, nodeInfo);
	}
	export const Node = BasicAssociation;
	export const Class = BasicAssociation;
	export namespace Commands {
		export type Type = {
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
		};
	}
	export enum Commands {
		query = 'QUERY'
	}
	export namespace Drivers {
		export type Type = {};
	}
	export enum Drivers {
	}
	export namespace Events {
		export type Type = {
			DON: {
				label: "On";
				name: "on";
			};
			DOF: {
				label: "Off";
				name: "off";
			};
		};
	}
	export enum Events {
		on = 'DON',
		off = 'DOF'
	}
}
