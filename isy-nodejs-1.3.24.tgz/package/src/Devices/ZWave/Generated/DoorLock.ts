/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import type { IntRange } from "type-fest";
import { ZWave } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = DoorLock.Commands.Type;
type Drivers = DoorLock.Drivers.Type;
type Events = DoorLock.Events.Type;

export class DoorLock extends Base<Drivers, Commands, Events> implements DoorLock.Interface {
	public override readonly commands = {
		LOCK: this.lock,
		UNLOCK: this.unlock,
		QUERY: this.query,
		SETTP: this.setTime,
		CONFIG: this.setConfiguration,
		WDU: this.writeChanges
	};

	static override nodeDefId = "111";
	static override implements = ['111'];
	declare readonly nodeDefId: '111';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		super(isy, nodeInfo);
		this.drivers.ST = Driver.create("ST", this, nodeInfo.state['ST'], { uom: UnitOfMeasure.DeadboltStatus, label: "Status", name: "status" });
		this.drivers.BATLVL = Driver.create("BATLVL", this, nodeInfo.state['BATLVL'], { uom: UnitOfMeasure.Percent, label: "Battery Level", name: "batteryLevel" });
		this.drivers.ERR = Driver.create("ERR", this, nodeInfo.state['ERR'], { uom: UnitOfMeasure.Index, label: "Responding", name: "responding" });
	}
	async lock() { return this.sendCommand("LOCK"); }
	async unlock(value?: ZWave.Unlock) { return this.sendCommand("UNLOCK", [value, UnitOfMeasure.Index]); }
	async query() { return this.sendCommand("QUERY"); }
	async setTime() { return this.sendCommand("SETTP"); }
	async setConfiguration(parameterNumber: number, parameterValue: number) { return this.sendCommand("CONFIG", { NUM: [parameterNumber, UnitOfMeasure.Raw1ByteUnsignedValue], VAL: parameterValue }); }
	async writeChanges() { return this.sendCommand("WDU"); }
	public get status(): (0 | 100 | 101 | 102) {
		return this.drivers.ST?.value;
	}
	public get batteryLevel(): IntRange<0, 100> {
		return this.drivers.BATLVL?.value;
	}
	public get responding(): ZWave.Error {
		return this.drivers.ERR?.value;
	}
}

NodeFactory.register(DoorLock);

export namespace DoorLock {
	export interface Interface extends Omit<InstanceType<typeof DoorLock>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is DoorLock {
		return ['111'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is DoorLock {
		return ['111'].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		return new DoorLock(isy, nodeInfo);
	}
	export const Node = DoorLock;
	export const Class = DoorLock;
	export namespace Commands {
		export type Type = {
			LOCK: (() => Promise<boolean>) & {
				label: "Lock";
				name: "lock";
			};
			UNLOCK: ((value?: ZWave.Unlock) => Promise<boolean>) & {
				label: "Unlock";
				name: "unlock";
			};
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
			SETTP: (() => Promise<boolean>) & {
				label: "Set Time";
				name: "setTime";
			};
			CONFIG: ((NUM: number, VAL: number) => Promise<boolean>) & {
				label: "Set Configuration";
				name: "setConfiguration";
			};
			WDU: (() => Promise<boolean>) & {
				label: "Write Changes";
				name: "writeChanges";
			};
		};
	}
	export enum Commands {
		lock = 'LOCK',
		unlock = 'UNLOCK',
		query = 'QUERY',
		setTime = 'SETTP',
		setConfiguration = 'CONFIG',
		writeChanges = 'WDU'
	}
	export namespace Drivers {
		export type Type = {
			ST: {
				uom: UnitOfMeasure.DeadboltStatus;
				value: (0 | 100 | 101 | 102);
				label: "Status";
				name: "status";
			};
			BATLVL: {
				uom: UnitOfMeasure.Percent;
				value: IntRange<0, 100>;
				label: "Battery Level";
				name: "batteryLevel";
			};
			ERR: {
				uom: UnitOfMeasure.Index;
				value: ZWave.Error;
				label: "Responding";
				name: "responding";
			};
		};
	}
	export enum Drivers {
		status = 'ST',
		batteryLevel = 'BATLVL',
		responding = 'ERR'
	}
	export namespace Events {
		export type Type = {};
	}
	export enum Events {
	}
}
