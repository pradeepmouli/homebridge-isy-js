/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import { ZWave } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = BinarySwitch.Commands.Type;
type Drivers = BinarySwitch.Drivers.Type;
type Events = BinarySwitch.Events.Type;

export class BinarySwitch extends Base<Drivers, Commands, Events> implements BinarySwitch.Interface {
	public override readonly commands = {
		DON: this.on,
		DOF: this.off,
		QUERY: this.query,
		CONFIG: this.setConfiguration,
		WDU: this.writeChanges
	};

	static override nodeDefId = "147";
	static override implements = ['147', "252", "259"];
	declare readonly nodeDefId: '147';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		super(isy, nodeInfo);
		this.drivers.ST = Driver.create("ST", this, nodeInfo.state['ST'], { uom: UnitOfMeasure.OffOn, label: "Status", name: "status" });
		this.drivers.ERR = Driver.create("ERR", this, nodeInfo.state['ERR'], { uom: UnitOfMeasure.Index, label: "Responding", name: "responding" });
	}
	async on(value?: (0 | 100)) { return this.sendCommand("DON", [value, UnitOfMeasure.OffOn]); }
	async off() { return this.sendCommand("DOF"); }
	async query() { return this.sendCommand("QUERY"); }
	async setConfiguration(parameterNumber: number, parameterValue: number) { return this.sendCommand("CONFIG", { NUM: [parameterNumber, UnitOfMeasure.Raw1ByteUnsignedValue], VAL: parameterValue }); }
	async writeChanges() { return this.sendCommand("WDU"); }
	public get status(): (0 | 100 | 101) {
		return this.drivers.ST?.value;
	}
	public get responding(): ZWave.Error {
		return this.drivers.ERR?.value;
	}
}

NodeFactory.register(BinarySwitch);

export namespace BinarySwitch {
	export interface Interface extends Omit<InstanceType<typeof BinarySwitch>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is BinarySwitch {
		return ['147'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is BinarySwitch {
		return ['147', "137"].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		return new BinarySwitch(isy, nodeInfo);
	}
	export const Node = BinarySwitch;
	export const Class = BinarySwitch;
	export namespace Commands {
		export type Type = {
			DON: ((value?: (0 | 100)) => Promise<boolean>) & {
				label: "On";
				name: "on";
			};
			DOF: (() => Promise<boolean>) & {
				label: "Off";
				name: "off";
			};
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
			CONFIG: ((NUM: number, VAL: number) => Promise<boolean>) & {
				label: "Set Configuration";
				name: "setConfiguration";
			};
			WDU: (() => Promise<boolean>) & {
				label: "Write Changes";
				name: "writeChanges";
			};
		};
	}
	export enum Commands {
		on = 'DON',
		off = 'DOF',
		query = 'QUERY',
		setConfiguration = 'CONFIG',
		writeChanges = 'WDU'
	}
	export namespace Drivers {
		export type Type = {
			ST: {
				uom: UnitOfMeasure.OffOn;
				value: (0 | 100 | 101);
				label: "Status";
				name: "status";
			};
			ERR: {
				uom: UnitOfMeasure.Index;
				value: ZWave.Error;
				label: "Responding";
				name: "responding";
			};
		};
	}
	export enum Drivers {
		status = 'ST',
		responding = 'ERR'
	}
	export namespace Events {
		export type Type = {
			DON: {
				label: "On";
				name: "on";
			};
			DOF: {
				label: "Off";
				name: "off";
			};
		};
	}
	export enum Events {
		on = 'DON',
		off = 'DOF'
	}
}
