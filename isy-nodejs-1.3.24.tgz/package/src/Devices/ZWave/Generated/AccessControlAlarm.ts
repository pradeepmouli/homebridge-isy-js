/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import type { IntRange } from "type-fest";
import { ZWave } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = AccessControlAlarm.Commands.Type;
type Drivers = AccessControlAlarm.Drivers.Type;
type Events = AccessControlAlarm.Events.Type;

export class AccessControlAlarm extends Base<Drivers, Commands, Events> implements AccessControlAlarm.Interface {
	public override readonly commands = {
		QUERY: this.query
	};

	static override nodeDefId = "306";
	static override implements = ['306'];
	declare readonly nodeDefId: '306';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		super(isy, nodeInfo);
		this.drivers.ALARM = Driver.create("ALARM", this, nodeInfo.state['ALARM'], { uom: UnitOfMeasure.Index, label: "Access Control", name: "accessControl" });
		this.drivers.USRNUM = Driver.create("USRNUM", this, nodeInfo.state['USRNUM'], { uom: UnitOfMeasure.UserNumber, label: "User Number", name: "userNumber" });
	}
	async query() { return this.sendCommand("QUERY"); }
	public get accessControl(): ZWave.AlertAc {
		return this.drivers.ALARM?.value;
	}
	public get userNumber(): IntRange<0, 255> {
		return this.drivers.USRNUM?.value;
	}
}

NodeFactory.register(AccessControlAlarm);

export namespace AccessControlAlarm {
	export interface Interface extends Omit<InstanceType<typeof AccessControlAlarm>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is AccessControlAlarm {
		return ['306'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is AccessControlAlarm {
		return ['306'].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.ZWave>) {
		return new AccessControlAlarm(isy, nodeInfo);
	}
	export const Node = AccessControlAlarm;
	export const Class = AccessControlAlarm;
	export namespace Commands {
		export type Type = {
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
		};
	}
	export enum Commands {
		query = 'QUERY'
	}
	export namespace Drivers {
		export type Type = {
			ALARM: {
				uom: UnitOfMeasure.Index;
				value: ZWave.AlertAc;
				label: "Access Control";
				name: "accessControl";
			};
			USRNUM: {
				uom: UnitOfMeasure.UserNumber;
				value: IntRange<0, 255>;
				label: "User Number";
				name: "userNumber";
			};
		};
	}
	export enum Drivers {
		accessControl = 'ALARM',
		userNumber = 'USRNUM'
	}
	export namespace Events {
		export type Type = {};
	}
	export enum Events {
	}
}
