/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import { UDI } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = TemperatureSensor.Commands.Type;
type Drivers = TemperatureSensor.Drivers.Type;
type Events = TemperatureSensor.Events.Type;

export class TemperatureSensor extends Base<Drivers, Commands, Events> implements TemperatureSensor.Interface {
	public override readonly commands = {};
	public readonly events: Events = {};
	static override nodeDefId = "EM3TempSensor";
	static override implements = ['EM3TempSensor'];
	declare readonly nodeDefId: 'EM3TempSensor';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.UDI>) {
		super(isy, nodeInfo);
		this.drivers.ST = Driver.create("ST", this, nodeInfo.state['ST'], { uom: UnitOfMeasure.Degree, label: "Temperature", name: "temperature" });
		this.drivers.ERR = Driver.create("ERR", this, nodeInfo.state['ERR'], { uom: UnitOfMeasure.Index, label: "Responding", name: "responding" });
	}
	public get temperature(): number {
		return this.drivers.ST?.value;
	}
	public get responding(): UDI.Error {
		return this.drivers.ERR?.value;
	}
}

NodeFactory.register(TemperatureSensor);

export namespace TemperatureSensor {
	export interface Interface extends Omit<InstanceType<typeof TemperatureSensor>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is TemperatureSensor {
		return ['EM3TempSensor'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is TemperatureSensor {
		return ['EM3TempSensor'].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.UDI>) {
		return new TemperatureSensor(isy, nodeInfo);
	}
	export const Node = TemperatureSensor;
	export const Class = TemperatureSensor;
	export namespace Commands {
		export type Type = {};
	}
	export enum Commands {
	}
	export namespace Drivers {
		export type Type = {
			ST: {
				uom: UnitOfMeasure.Degree;
				value: number;
				label: "Temperature";
				name: "temperature";
			};
			ERR: {
				uom: UnitOfMeasure.Index;
				value: UDI.Error;
				label: "Responding";
				name: "responding";
			};
		};
	}
	export enum Drivers {
		temperature = 'ST',
		responding = 'ERR'
	}
	export namespace Events {
		export type Type = {};
	}
	export enum Events {
	}
}
