/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = MatterController.Commands.Type;
type Drivers = MatterController.Drivers.Type;
type Events = MatterController.Events.Type;

export class MatterController extends Base<Drivers, Commands, Events> implements MatterController.Interface {
	public override readonly commands = {};
	static override nodeDefId = "CTL";
	static override implements = ['CTL'];
	declare readonly nodeDefId: 'CTL';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.Poly>) {
		super(isy, nodeInfo);
		this.drivers.ST = Driver.create("ST", this, nodeInfo.state['ST'], { uom: UnitOfMeasure.Index, label: "Plugin status", name: "pluginStatus" });
		this.drivers.GV0 = Driver.create("GV0", this, nodeInfo.state['GV0'], { uom: UnitOfMeasure.Index, label: "Matter bridge status", name: "matterBridgeStatus" });
	}
	public get pluginStatus(): (0 | 1) {
		return this.drivers.ST?.value;
	}
	public get matterBridgeStatus(): (0 | 1) {
		return this.drivers.GV0?.value;
	}
}

NodeFactory.register(MatterController);

export namespace MatterController {
	export interface Interface extends Omit<InstanceType<typeof MatterController>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is MatterController {
		return ['CTL'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is MatterController {
		return ['CTL'].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.Poly>) {
		return new MatterController(isy, nodeInfo);
	}
	export const Node = MatterController;
	export const Class = MatterController;
	export namespace Commands {
		export type Type = {};
	}
	export enum Commands {
	}
	export namespace Drivers {
		export type Type = {
			ST: {
				uom: UnitOfMeasure.Index;
				value: (0 | 1);
				label: "Plugin status";
				name: "pluginStatus";
			};
			GV0: {
				uom: UnitOfMeasure.Index;
				value: (0 | 1);
				label: "Matter bridge status";
				name: "matterBridgeStatus";
			};
		};
	}
	export enum Drivers {
		pluginStatus = 'ST',
		matterBridgeStatus = 'GV0'
	}
	export namespace Events {
		export type Type = {};
	}
	export enum Events {
	}
}
