import { CompositeDevice } from '../CompositeDevice.js';
import { DimmerLamp } from './Generated/DimmerLamp.js';
import { FanLincMotor } from './Generated/FanLincMotor.js';

export namespace Fan {
	export const Nodes = { light: DimmerLamp, motor: FanLincMotor };

	class FanDevice extends CompositeDevice.of(Fan.Nodes, { light: 1, motor: 2 }) {
		static deviceDefId = 'Fan';
	}

	export const Class = FanDevice;
	export const Motor = FanLincMotor;

	export const Light = DimmerLamp;
}
