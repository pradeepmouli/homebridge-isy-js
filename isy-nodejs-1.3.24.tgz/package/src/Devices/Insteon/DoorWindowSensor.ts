import { CompositeDevice } from '../CompositeDevice.js';
import { BinaryAlarm } from './Generated/BinaryAlarm.js';

const nodes = { open: BinaryAlarm, closed: BinaryAlarm, heartbeat: BinaryAlarm, lowBattery: BinaryAlarm };
export class DoorWindowSensor extends CompositeDevice.of(nodes, { closed: 1, open: 2, heartbeat: 3, lowBattery: 4 }) {}

export namespace DoorWindowSensor {
	export const Nodes = nodes;
	export const Class = DoorWindowSensor;

	export const Open = BinaryAlarm;

	export const Closed = BinaryAlarm;

	export const Heartbeat = BinaryAlarm;

	export const LowBattery = BinaryAlarm;
}
