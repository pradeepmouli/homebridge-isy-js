//import Base from "./InsteonBaseDevice.js"

export { InsteonDeviceNode as Base } from './InsteonDeviceNode.js';

export { OnOffOutlet } from './OnOffOutlet.js';

export * from './Generated/index.js';

//export { InsteonDimmableDevice as Dimmable } from './InsteonDimmableDevice.js';

export { Fan } from './Fan.js';

//export { InsteonRelayDevice as Relay } from './InsteonRelayDevice.js';

export { COSensor } from './COSensor.js';

export { LeakSensor } from './LeakSensor.js';

export { InsteonMotionSensorDevice as MotionSensor } from './InsteonMotionSensorDevice.js';

export { SmokeSensor } from './SmokeSensor.js';

export { DoorWindowSensor } from './DoorWindowSensor.js';

export { IOModule } from './IOModule.js';

export { InsteonDimmerOutletDevice as DimmerOutlet } from './InsteonDimmerOutletDevice.js';

/*export const Insteon = {
  LeakSensor: InsteonLeakSensorDevice,
  MotionSensor: InsteonMotionSensorDevice,
  SmokeSensor: InsteonSmokeSensorDevice,
  DoorWindowSensor: InsteonDoorWindowSensorDevice,
  DimmerOutlet: InsteonDimmerOutletDevice,
  Thermostat: InsteonThermostatDevice,
  Lock: InsteonLockDevice,
  Fan: InsteonFanDevice,
...Generated */
