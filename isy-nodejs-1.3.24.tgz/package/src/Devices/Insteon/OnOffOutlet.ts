import 'winston';
import { RelayLamp } from './Generated/RelayLamp.js';

import { CompositeDevice } from '../CompositeDevice.js';

const nodes = { top: RelayLamp, bottom: RelayLamp };
class OnOffOutletDevice extends CompositeDevice.of(nodes, { top: 1, bottom: 2 }) {
	static deviceDefId = 'OnOffOutlet';
}

export namespace OnOffOutlet {
	export const Nodes = nodes;
	export const Class = OnOffOutletDevice;
}
