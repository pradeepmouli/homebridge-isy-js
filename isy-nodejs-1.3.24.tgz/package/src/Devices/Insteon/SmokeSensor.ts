import { Category, CompositeDevice } from '../../ISY.js';

import 'winston';
import { BinaryAlarm } from './Generated/BinaryAlarm.js';

export namespace SmokeSensor {
	export const Nodes = { sensor: BinaryAlarm };
	export class Class extends CompositeDevice.of(Nodes, { sensor: 1 }) {}

	export const Sensor = BinaryAlarm;

	export const LowBattery = BinaryAlarm;

	export const typeCodes = [Category.Insteon.IrrigationControl];
}
