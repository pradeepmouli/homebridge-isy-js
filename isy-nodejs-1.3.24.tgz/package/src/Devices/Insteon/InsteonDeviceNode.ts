import 'winston';
import { Converter } from '../../Converters.js';
import { Driver } from '../../Definitions/Global/Drivers.js';
import { Family } from '../../Definitions/Global/Families.js';
import { UnitOfMeasure as UOM, UnitOfMeasure } from '../../Definitions/Global/UOM.js';
import { ISY } from '../../ISY.js';
import { ISYNode } from '../../ISYNode.js';
import { NodeInfo } from '../../Model/NodeInfo.js';
import { byteToDegree, pctToByte } from '../../Utils.js';
import { ISYDeviceNode } from '../ISYDeviceNode.js';

// import { InsteonNLS } from './insteonfam.js'
export class InsteonDeviceNode<
	D extends ISYNode.DriverSignatures = Driver.Signatures<'ST'>,
	C extends ISYNode.CommandSignatures = {},
	E extends ISYNode.EventSignatures = {},
> extends ISYDeviceNode<Family.Insteon, D, C, E> {
	// #region Constructors (1)
	override readonly manufacturer: string = 'Insteon Technologies, Inc.';

	static override family: Family.Insteon = Family.Insteon;

	constructor(isy: ISY, deviceNode: NodeInfo) {
		super(isy, deviceNode);
		this.family = Family.Insteon;
		//// this.productName = InsteonNLS.getDeviceDescription(String.fromCharCode(category,device,version));
		//his.childDevices = {};
	}

	// #endregion Constructors (1)

	// #region Public Methods (3)

	public override convertFrom(value: any, uom: UnitOfMeasure, driver: keyof D = null): any {
		switch (uom) {
			case UOM.DegreeX2:
				return byteToDegree(value);
			case UOM.LevelFrom0To255:
				return Converter.Standard.LevelFrom0To255.Percent.to(value);
			case UOM.Fahrenheit:
				return value / 10;
			default:
				return super.convertFrom(value, uom);
		}
	}

	public override convertTo(value: any, uom: UnitOfMeasure, propertyName: keyof D = null): any {
		const nuom = super.convertTo(value, uom);
		switch (uom) {
			case UOM.DegreeX2:
				return nuom * 2;
			case UOM.LevelFrom0To255:
				return pctToByte(nuom);
			case UOM.Fahrenheit:
				return Math.round(value * 10);
			default:
				return nuom;
		}
	}

	// #endregion Public Methods (3)
}
