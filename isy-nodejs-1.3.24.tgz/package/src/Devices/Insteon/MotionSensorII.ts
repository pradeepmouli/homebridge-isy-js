import { CompositeDevice } from '../../ISY.js';

import 'winston';
import { BinaryAlarm, Pir2844, Pir2844OnOff } from './Generated/index.js';

const nodes = { occupied: Pir2844OnOff, dawnDusk: Pir2844 };

export class MotionSensorII extends CompositeDevice.of(nodes, { occupied: 1, dawnDusk: 2 }) {}

export namespace MotionSensorII {
	export const Nodes = nodes;

	export const Class = MotionSensorII;

	export const Occupied = Pir2844OnOff;

	export const DawnDusk = Pir2844;

	export const Heartbeat = BinaryAlarm;

	export const LowBattery = BinaryAlarm;
}
