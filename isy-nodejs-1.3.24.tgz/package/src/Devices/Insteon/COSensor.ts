import { Category, CompositeDevice } from '../../ISY.js';

import 'winston';
import { BinaryAlarm } from './Generated/BinaryAlarm.js';

export namespace COSensor {
	export const Nodes = { sensor: BinaryAlarm, lowBattery: BinaryAlarm };

	class COSensorDevice extends CompositeDevice.of(COSensor.Nodes, { sensor: 1, lowBattery: 3 }) {}

	export const Class = COSensorDevice;
	//export class Class extends CompositeDevice.of(Nodes, { sensor: 1, lowBattery: 3 }) {}

	export const Sensor = BinaryAlarm;

	export const LowBattery = BinaryAlarm;

	export const typeCodes = [Category.Insteon.IrrigationControl];
}
