import { CompositeDevice } from '../../ISY.js';

import 'winston';
import { BinaryAlarm } from './Generated/index.js';

const nodes = { dry: BinaryAlarm, wet: BinaryAlarm, heartbeat: BinaryAlarm, lowBattery: BinaryAlarm };

export class LeakSensor extends CompositeDevice.of(nodes, { dry: 1, wet: 2, heartbeat: 3, lowBattery: 4 }) {}

export namespace LeakSensor {
	export const Nodes = nodes;

	export const Class = LeakSensor;

	export const Dry = BinaryAlarm;

	export const Wet = BinaryAlarm;

	export const Heartbeat = BinaryAlarm;

	export const LowBattery = BinaryAlarm;
}
