/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import { Insteon } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = KeypadButton.Commands.Type;
type Drivers = KeypadButton.Drivers.Type;
type Events = KeypadButton.Events.Type;

export class KeypadButton extends Base<Drivers, Commands, Events> implements KeypadButton.Interface {
	public override readonly commands = {
		QUERY: this.query,
		BL: this.backlight,
		WDU: this.writeChanges
	};
	static override nodeDefId = "KeypadButton";
	static override implements = ['KeypadButton', "EZIO2x4_Input", "EZIO2x4_Input_ADV", "SirenAlert", "SirenArm"];
	declare readonly nodeDefId: 'KeypadButton' | "KeypadButton_ADV";
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.Insteon>) {
		super(isy, nodeInfo);
		this.drivers.ST = Driver.create("ST", this, nodeInfo.state['ST'], { uom: UnitOfMeasure.Percent, label: "Status", name: "status" });
		this.drivers.ERR = Driver.create("ERR", this, nodeInfo.state['ERR'], { uom: UnitOfMeasure.Index, label: "Responding", name: "responding" });
	}
	async query() { return this.sendCommand("QUERY"); }
	async backlight(value: Insteon.Backlight) { return this.sendCommand("BL", [value, UnitOfMeasure.Index]); }
	async writeChanges() { return this.sendCommand("WDU"); }
	public get status(): Insteon.OnLevelRelay {
		return this.drivers.ST?.value;
	}
	public get responding(): Insteon.Error {
		return this.drivers.ERR?.value;
	}
}

NodeFactory.register(KeypadButton);
NodeFactory.register(KeypadButton, "KeypadButton_ADV");

export namespace KeypadButton {
	export interface Interface extends Omit<InstanceType<typeof KeypadButton>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is KeypadButton {
		return ['KeypadButton', "KeypadButton_ADV"].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is KeypadButton {
		return ['KeypadButton', "KeypadRelay", "KeypadRelay_ADV", "KeypadButton_ADV"].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.Insteon>) {
		return new KeypadButton(isy, nodeInfo);
	}
	export const Node = KeypadButton;
	export const Class = KeypadButton;
	export namespace Commands {
		export type Type = {
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
			BL: ((value: Insteon.Backlight) => Promise<boolean>) & {
				label: "Backlight";
				name: "backlight";
			};
			WDU: (() => Promise<boolean>) & {
				label: "Write Changes";
				name: "writeChanges";
			};
		};
	}
	export enum Commands {
		query = 'QUERY',
		backlight = 'BL',
		writeChanges = 'WDU'
	}
	export namespace Drivers {
		export type Type = {
			ST: {
				uom: UnitOfMeasure.Percent;
				value: Insteon.OnLevelRelay;
				label: "Status";
				name: "status";
			};
			ERR: {
				uom: UnitOfMeasure.Index;
				value: Insteon.Error;
				label: "Responding";
				name: "responding";
			};
		};
	}
	export enum Drivers {
		status = 'ST',
		responding = 'ERR'
	}
	export namespace Events {
		export type Type = {
			DON: {
				label: "On";
				name: "on";
			};
			DOF: {
				label: "Off";
				name: "off";
			};
			DFOF: {
				label: "Fast Off";
				name: "fastOff";
			};
			DFON: {
				label: "Fast On";
				name: "fastOn";
			};
			FDUP: {
				label: "Fade Up";
				name: "fadeUp";
			};
			FDDOWN: {
				label: "Fade Down";
				name: "fadeDown";
			};
			FDSTOP: {
				label: "Fade Stop";
				name: "fadeStop";
			};
		};
	}
	export enum Events {
		on = 'DON',
		off = 'DOF',
		fastOff = 'DFOF',
		fastOn = 'DFON',
		fadeUp = 'FDUP',
		fadeDown = 'FDDOWN',
		fadeStop = 'FDSTOP'
	}
}
