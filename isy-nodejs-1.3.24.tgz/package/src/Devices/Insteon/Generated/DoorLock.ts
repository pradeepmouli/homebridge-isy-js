/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import { Insteon } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = DoorLock.Commands.Type;
type Drivers = DoorLock.Drivers.Type;
type Events = DoorLock.Events.Type;

export class DoorLock extends Base<Drivers, Commands, Events> implements DoorLock.Interface {
	public override readonly commands = {
		DON: this.lock,
		DOF: this.unlock,
		WDU: this.writeChanges
	};
	static override nodeDefId = "DoorLock";
	static override implements = ['DoorLock', "SirenAlert", "SirenArm"];
	declare readonly nodeDefId: 'DoorLock';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.Insteon>) {
		super(isy, nodeInfo);
		this.drivers.ST = Driver.create("ST", this, nodeInfo.state['ST'], { uom: UnitOfMeasure.Percent, label: "Status", name: "status" });
		this.drivers.ERR = Driver.create("ERR", this, nodeInfo.state['ERR'], { uom: UnitOfMeasure.Index, label: "Responding", name: "responding" });
	}
	async lock() { return this.sendCommand("DON"); }
	async unlock() { return this.sendCommand("DOF"); }
	async writeChanges() { return this.sendCommand("WDU"); }
	public get status(): Insteon.Lock {
		return this.drivers.ST?.value;
	}
	public get responding(): Insteon.Error {
		return this.drivers.ERR?.value;
	}
}

NodeFactory.register(DoorLock);

export namespace DoorLock {
	export interface Interface extends Omit<InstanceType<typeof DoorLock>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is DoorLock {
		return ['DoorLock'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is DoorLock {
		return ['DoorLock', "RelayLampSwitch", "RelayLampSwitch_ADV", "RelayLampSwitchLED", "RelayLampSwitchLED_ADV", "KeypadRelay", "KeypadRelay_ADV", "FanLincMotor"].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.Insteon>) {
		return new DoorLock(isy, nodeInfo);
	}
	export const Node = DoorLock;
	export const Class = DoorLock;
	export namespace Commands {
		export type Type = {
			DON: (() => Promise<boolean>) & {
				label: "Lock";
				name: "lock";
			};
			DOF: (() => Promise<boolean>) & {
				label: "Unlock";
				name: "unlock";
			};
			WDU: (() => Promise<boolean>) & {
				label: "Write Changes";
				name: "writeChanges";
			};
		};
	}
	export enum Commands {
		lock = 'DON',
		unlock = 'DOF',
		writeChanges = 'WDU'
	}
	export namespace Drivers {
		export type Type = {
			ST: {
				uom: UnitOfMeasure.Percent;
				value: Insteon.Lock;
				label: "Status";
				name: "status";
			};
			ERR: {
				uom: UnitOfMeasure.Index;
				value: Insteon.Error;
				label: "Responding";
				name: "responding";
			};
		};
	}
	export enum Drivers {
		status = 'ST',
		responding = 'ERR'
	}
	export namespace Events {
		export type Type = {};
	}
	export enum Events {
	}
}
