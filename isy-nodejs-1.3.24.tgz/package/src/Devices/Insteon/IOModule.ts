import { CompositeDevice } from '../../ISY.js';

import 'winston';
import { BinaryAlarm } from './Generated/BinaryAlarm.js';
import { BinaryControl } from './Generated/BinaryControl.js';
import { RelayLamp } from './Generated/RelayLamp.js';

export namespace IOModule {
	export const Nodes = { sensor: BinaryControl, relay: RelayLamp };
	class IOModuleDevice extends CompositeDevice.of(Nodes, { sensor: 1, relay: 2 }) {}

	export const Class = IOModuleDevice;

	export const Sensor = BinaryAlarm;

	export const LowBattery = BinaryAlarm;
}
