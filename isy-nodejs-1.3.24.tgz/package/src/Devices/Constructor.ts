import { Constructor as BaseConstructor } from 'type-fest';

export type Constructor<T> = BaseConstructor<T>;
