/* THIS FILE WAS AUTOMATICALLY GENERATED. DO NOT EDIT DIRECTLY. */

import { Family, UnitOfMeasure } from "../../../Definitions/Global/index.js";
import type { NodeInfo } from "../../../Model/NodeInfo.js";
import { ISY } from "../../../ISY.js";
import { ISYNode } from "../../../ISYNode.js";
import { ISYDeviceNode } from "../../ISYDeviceNode.js";
import { Base } from "../index.js";
import { Driver } from "../../../Definitions/Global/Drivers.js";
import type { IntRange } from "type-fest";
import { ZigBee } from "../../../Definitions/index.js";
import { NodeFactory } from "../../NodeFactory.js";

type Commands = ColorXY.Commands.Type;
type Drivers = ColorXY.Drivers.Type;

export class ColorXY extends Base<Drivers, Commands> implements ColorXY.Interface {
	public override readonly commands = {
		MOVETOXY: this.moveToXy,
		MOVEXY: this.moveXy,
		STEPXY: this.stepXy,
		MOVETOCT: this.moveToTemperature,
		MOVECT: this.moveTemperature,
		STEPCT: this.stepTemperature,
		UNITS: this.updatePreferredUnits,
		STOP: this.stop,
		QUERY: this.query
	};
	static override nodeDefId = "108";
	static override implements = ['108'];
	declare readonly nodeDefId: '108';
	constructor (isy: ISY, nodeInfo: NodeInfo<Family.ZigBee>) {
		super(isy, nodeInfo);
		this.drivers.GV0 = Driver.create("GV0", this, nodeInfo.state['GV0'], { uom: UnitOfMeasure.ColorXY, label: "Color X", name: "colorX" });
		this.drivers.GV1 = Driver.create("GV1", this, nodeInfo.state['GV1'], { uom: UnitOfMeasure.ColorXY, label: "Color Y", name: "colorY" });
		this.drivers.GV2 = Driver.create("GV2", this, nodeInfo.state['GV2'], { uom: UnitOfMeasure.Kelvin, label: "Color Temperature K", name: "colorTemperatureK" });
		this.drivers.GV3 = Driver.create("GV3", this, nodeInfo.state['GV3'], { uom: UnitOfMeasure.MiredColorTemp, label: "Color Temperature Mired", name: "colorTemperatureMired" });
		this.drivers.GV4 = Driver.create("GV4", this, nodeInfo.state['GV4'], { uom: UnitOfMeasure.Index, label: "Preferred Units", name: "preferredUnits" });
	}
	async moveToXy(x: number, y: number, duration?: number) { return this.sendCommand("MOVETOXY", { X: [x, UnitOfMeasure.ColorXY], Y: [y, UnitOfMeasure.ColorXY], DUR: [duration, UnitOfMeasure.DurationInSeconds] }); }
	async moveXy(rateX?: number, rateY?: number) { return this.sendCommand("MOVEXY", { RATEX: [rateX, UnitOfMeasure.StepsPerSecond], RATEY: [rateY, UnitOfMeasure.StepsPerSecond] }); }
	async stepXy(stepX?: number, stepY?: number) { return this.sendCommand("STEPXY", { STEPX: [stepX, UnitOfMeasure.ColorXY], STEPY: [stepY, UnitOfMeasure.ColorXY] }); }
	async moveToTemperature(color: number, duration?: number) { return this.sendCommand("MOVETOCT", { COLOR: [color, UnitOfMeasure.Kelvin], DUR: [duration, UnitOfMeasure.DurationInSeconds] }); }
	async moveTemperature(mode: ZigBee.ColorControlMoveMode, min?: number, max?: number, rate?: number) { return this.sendCommand("MOVECT", { MIN: [min, UnitOfMeasure.Kelvin], MAX: [max, UnitOfMeasure.Kelvin], MODE: [mode, UnitOfMeasure.Index], RATE: [rate, UnitOfMeasure.StepsPerSecond] }); }
	async stepTemperature(min?: number, max?: number, stepSize?: number, mode?: ZigBee.ColorControlStepMode, duration?: number) { return this.sendCommand("STEPCT", { MIN: [min, UnitOfMeasure.Kelvin], MAX: [max, UnitOfMeasure.Kelvin], SIZE: [stepSize, UnitOfMeasure.Kelvin], MODE: [mode, UnitOfMeasure.Index], DUR: [duration, UnitOfMeasure.DurationInSeconds] }); }
	async updatePreferredUnits(value: ZigBee.ColorTemperatureUnit) { return this.sendCommand("UNITS", [value, UnitOfMeasure.Index]); }
	async stop() { return this.sendCommand("STOP"); }
	async query() { return this.sendCommand("QUERY"); }
	public get colorX(): IntRange<0, 1> {
		return this.drivers.GV0?.value;
	}
	public get colorY(): IntRange<0, 1> {
		return this.drivers.GV1?.value;
	}
	public get colorTemperatureK(): IntRange<0, 1> {
		return this.drivers.GV2?.value;
	}
	public get colorTemperatureMired(): IntRange<0, 1> {
		return this.drivers.GV3?.value;
	}
	public get preferredUnits(): ZigBee.ColorTemperatureUnit {
		return this.drivers.GV4?.value;
	}
}

NodeFactory.register(ColorXY);

export namespace ColorXY {
	export interface Interface extends Omit<InstanceType<typeof ColorXY>, keyof ISYDeviceNode<any, any, any, any>> {
	}
	export function is(node: ISYNode<any, any, any, any>): node is ColorXY {
		return ['108'].includes(node.nodeDefId);
	}
	export function isImplementedBy(node: ISYNode<any, any, any, any>): node is ColorXY {
		return ['108'].includes(node.nodeDefId);
	}
	export function create(isy: ISY, nodeInfo: NodeInfo<Family.ZigBee>) {
		return new ColorXY(isy, nodeInfo);
	}
	export const Node = ColorXY;
	export const Class = ColorXY;
	export namespace Commands {
		export type Type = {
			MOVETOXY: ((X: number, Y: number, DUR?: number) => Promise<boolean>) & {
				label: "Move To XY";
				name: "moveToXy";
			};
			MOVEXY: ((RATEX?: number, RATEY?: number) => Promise<boolean>) & {
				label: "Move XY";
				name: "moveXy";
			};
			STEPXY: ((STEPX?: number, STEPY?: number) => Promise<boolean>) & {
				label: "Step XY";
				name: "stepXy";
			};
			MOVETOCT: ((COLOR: number, DUR?: number) => Promise<boolean>) & {
				label: "Move To Temperature";
				name: "moveToTemperature";
			};
			MOVECT: ((MODE: ZigBee.ColorControlMoveMode, MIN?: number, MAX?: number, RATE?: number) => Promise<boolean>) & {
				label: "Move Temperature";
				name: "moveTemperature";
			};
			STEPCT: ((MIN?: number, MAX?: number, SIZE?: number, MODE?: ZigBee.ColorControlStepMode, DUR?: number) => Promise<boolean>) & {
				label: "Step Temperature";
				name: "stepTemperature";
			};
			UNITS: ((value: ZigBee.ColorTemperatureUnit) => Promise<boolean>) & {
				label: "Preferred Units";
				name: "updatePreferredUnits";
			};
			STOP: (() => Promise<boolean>) & {
				label: "Stop";
				name: "stop";
			};
			QUERY: (() => Promise<boolean>) & {
				label: "Query";
				name: "query";
			};
		};
	}
	export enum Commands {
		moveToXy = 'MOVETOXY',
		moveXy = 'MOVEXY',
		stepXy = 'STEPXY',
		moveToTemperature = 'MOVETOCT',
		moveTemperature = 'MOVECT',
		stepTemperature = 'STEPCT',
		updatePreferredUnits = 'UNITS',
		stop = 'STOP',
		query = 'QUERY'
	}
	export namespace Drivers {
		export type Type = {
			GV0: {
				uom: UnitOfMeasure.ColorXY;
				value: IntRange<0, 1>;
				label: "Color X";
				name: "colorX";
			};
			GV1: {
				uom: UnitOfMeasure.ColorXY;
				value: IntRange<0, 1>;
				label: "Color Y";
				name: "colorY";
			};
			GV2: {
				uom: UnitOfMeasure.Kelvin;
				value: IntRange<0, 1>;
				label: "Color Temperature K";
				name: "colorTemperatureK";
			};
			GV3: {
				uom: UnitOfMeasure.MiredColorTemp;
				value: IntRange<0, 1>;
				label: "Color Temperature Mired";
				name: "colorTemperatureMired";
			};
			GV4: {
				uom: UnitOfMeasure.Index;
				value: ZigBee.ColorTemperatureUnit;
				label: "Preferred Units";
				name: "preferredUnits";
			};
		};
	}
	export enum Drivers {
		colorX = 'GV0',
		colorY = 'GV1',
		colorTemperatureK = 'GV2',
		colorTemperatureMired = 'GV3',
		preferredUnits = 'GV4'
	}
}
