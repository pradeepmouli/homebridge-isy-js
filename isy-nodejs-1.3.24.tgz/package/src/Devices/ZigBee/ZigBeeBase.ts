import 'winston';
import { Family } from '../../Definitions/Global/Families.js';
import { ISYNode } from '../../ISYNode.js';
import type { NodeDef } from '../../Model/NodeDef.js';
import { DynamicNode } from '../DynamicNode.js';

// import { InsteonNLS } from './insteonfam'
export class ZigBeeBase<
	D extends ISYNode.DriverSignatures,
	C extends ISYNode.CommandSignatures,
	E extends ISYNode.EventSignatures = {},
> extends DynamicNode<Family.ZigBee, D, C, E> {
	static override family: Family.ZigBee = Family.ZigBee;
	public async getNodeDef(nodeDefId: string): Promise<NodeDef> {
		let n = (
			await this.isy.sendRequest(`zmatter/zigbee/node/${this.address}/def/get?full=true`, { trailingSlash: false })
		).nodeDefs.nodedef;

		//this.logger(`Node is ZigBee. NodeDef: ${logStringify(n)}`);
		return n;
	}
}
