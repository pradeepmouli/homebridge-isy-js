import { BitFlag, type ClusterType, type TlvSchema, type TypeFromPartialBitSchema } from '@matter/types';
import type { SnakeCase } from 'type-fest';

export interface ZigBeeClusterData<C extends ClusterType> {
	clusterId: C['id'];
	clusterName: Uppercase<SnakeCase<C['name']>>;
	endpoint: number;
	data: {
		[x in keyof C['attributes']]: C['attributes'][x]['schema'] extends TlvSchema<infer R> ? R : any;
	};
}

export type ZigBeeClusterDataMap = {
	[x: string]: ZigBeeClusterData<ClusterType>;
};

export function hasBitFlag(
	value: TypeFromPartialBitSchema<{
		[flag: string]: BitFlag;
		[flag: number]: BitFlag;
		[flag: symbol]: BitFlag;
	}>,
	flag: BitFlag
): boolean {
	if (typeof value !== 'number' && typeof value !== 'bigint') return value[flag.offset];
	else {
		let val = Math.pow(2, flag.offset);

		return (value & val) == val;
	}
}
