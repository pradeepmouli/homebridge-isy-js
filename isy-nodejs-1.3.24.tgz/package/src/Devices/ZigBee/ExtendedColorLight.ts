import { CompositeDevice, type Family, type ISY } from '../../ISY.js';
import type { NodeInfo } from '../../Model/NodeInfo.js';

import 'winston';

import type { LevelControl } from '@matter/main/clusters';
import type { ColorControl } from '@matter/types/clusters/color-control';
import type { OnOff } from '@matter/types/clusters/on-off';

import { ColorHueSat } from './Generated/ColorHueSat.js';
import { ColorXY } from './Generated/ColorXY.js';
import { OnOffLevel } from './Generated/OnOffLevel.js';
import type { ZigBeeClusterData, ZigBeeClusterDataMap } from './ZigbeeClusterData.js';

const nodes = { onOff: OnOffLevel, colorHS: ColorHueSat, colorXY: ColorXY };

export class ExtendedColorLight extends CompositeDevice.of<Family.ZigBee, typeof nodes>(nodes, {
	onOff: 103,
	colorHS: 106,
	colorXY: 108,
}) {
	constructor(isy: ISY, node: NodeInfo<Family.ZigBee>, clusterData: ZigBeeClusterDataMap) {
		super(isy, node);
		this.applyClusterData(clusterData as any);
	}

	ZigBeeClusterData: {
		// @ts-ignore
		COLOR_CONTROL: ZigBeeClusterData<ColorControl.Cluster>;
		// @ts-ignore
		ON_OFF_SWITCH: ZigBeeClusterData<OnOff.Cluster>;
		// @ts-ignore
		LEVEL_CONTROL: ZigBeeClusterData<LevelControl.Cluster>;
	};
	//@ts-ignore
	applyClusterData(clusterData: typeof this.ZigBeeClusterData) {
		this.ZigBeeClusterData = clusterData;
	}
}

export namespace ExtendedColorLight {
	export const Nodes = nodes;

	export const Class = ExtendedColorLight;

	export const OnOff = nodes.onOff;

	export const ColorHS = nodes.colorHS;

	export const ColorXY = nodes.colorXY;
}
