import { CompositeDevice, type Family } from '../../ISY.js';

import 'winston';

import { OnOffLevel } from './Generated/index.js';

const nodes = { onOffLevel: OnOffLevel };

export class DimmableLight extends CompositeDevice.of<Family.ZigBee, typeof nodes>(nodes, { onOffLevel: 103 }) {}

export namespace OnOffLight {
	export const Nodes = nodes;

	export const Class = OnOffLight;

	export const OnOff = nodes.onOffLevel;
}
