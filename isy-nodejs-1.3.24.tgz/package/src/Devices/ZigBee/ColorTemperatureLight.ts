import { type Family, CompositeDevice } from '../../ISY.js';

import 'winston';

import { ColorHueSat, ColorXY, OnOffLevel } from './Generated/index.js';

const nodes = { onOff: OnOffLevel, colorHS: ColorHueSat, colorTemp: ColorXY };

export class ColorTemperatureLight extends CompositeDevice.of<Family.ZigBee, typeof nodes>(nodes, {
	onOff: 103,
	colorHS: 106,
	colorTemp: 108,
}) {}

export namespace ColorTemperatureLight {
	export const Nodes = nodes;

	export const Class = ColorTemperatureLight;

	export const OnOff = nodes.onOff;

	export const ColorHS = nodes.colorHS;

	export const ColorXY = nodes.colorTemp;
}
