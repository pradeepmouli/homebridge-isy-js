import { CompositeDevice, type Family } from '../../ISY.js';

import 'winston';

import { OnOffLevel } from './Generated/index.js';

const nodes = { onOff: OnOffLevel };

export class OnOffLight extends CompositeDevice.of<Family.ZigBee, typeof nodes>(nodes, { onOff: 103 }) {}

export namespace OnOffLight {
	export const Nodes = nodes;

	export const Class = OnOffLight;

	export const OnOff = nodes.onOff;
}
