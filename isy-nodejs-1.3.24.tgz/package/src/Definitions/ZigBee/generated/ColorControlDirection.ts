export enum ColorControlDirection {
    ShortestDistance = 0,
    LongestDistance = 1,
    Up = 2,
    Down = 3
}
