export enum DoorLockUserType {
    Unrestricted = 0,
    DateScheduled = 1,
    WeekdayScheduled = 2,
    Master = 3,
    NoAccess = 4
}
