export enum ColorControlMoveMode {
    Stop = 0,
    Up = 1,
    _2Reserved = 2,
    Down = 3
}
