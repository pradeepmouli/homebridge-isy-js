export enum HueSaturation {
    Hue = 0,
    Saturation = 1
}
