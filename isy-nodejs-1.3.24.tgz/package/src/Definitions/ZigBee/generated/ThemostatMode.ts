export enum ThemostatMode {
    Off = 0,
    Auto = 1,
    Reserved = 2,
    Cool = 3,
    Heat = 4,
    EmergencyHeating = 5,
    Precooling = 6,
    FanOnly = 7,
    Dry = 8,
    Sleep = 9
}
