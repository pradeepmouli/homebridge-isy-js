export enum ColorTemperatureUnit {
    Kelvin = 0,
    Mired = 1
}
