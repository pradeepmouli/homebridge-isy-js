export enum WindowCoveringDirection {
    Up = 0,
    Down = 1,
    None = 3
}
