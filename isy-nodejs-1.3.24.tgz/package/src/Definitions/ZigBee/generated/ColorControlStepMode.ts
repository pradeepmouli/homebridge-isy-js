export enum ColorControlStepMode {
    _0Reserved = 0,
    Up = 1,
    _2Reserved = 2,
    Down = 3
}
