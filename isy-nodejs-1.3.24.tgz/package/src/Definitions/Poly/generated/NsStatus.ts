export enum NsStatus {
    Disconnected = 0,
    Connected = 1,
    Failed = 2
}
