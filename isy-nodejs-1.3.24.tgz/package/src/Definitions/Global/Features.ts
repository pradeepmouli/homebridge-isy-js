import type { ISY } from '../../ISY.js';
import type { ISYDevice } from '../../ISYDevice.js';

export enum Feature {
	None = 0,
	Dimmable = 1,
	Socket = 2,
	Switch = 4,
	HasLoad = 8,
	Queryable = 16,
	BatteryPowered = 32,
}

export namespace Feature {
	const FeatureE = Feature;

	export function has(device: ISYDevice.Any, feature: Feature) {
		return (device.features & feature) === feature;
	}

	export function add(device: ISYDevice.Any, feature: Feature) {
		device.features |= feature;
	}

	export function get(device: ISYDevice.Any): Feature[] {
		let features: Feature[] = [];
		for (const l in Object.values(Feature)) {
			if (typeof l !== 'string')
				if (has(device, l)) {
					features.push(l);
				}
		}
		return features;
	}
}
