export enum OnLevelRelay {
    Off = 0,
    On = 100
}


export namespace OnLevelRelay {

	export const to =
	{
		Boolean(value: OnLevelRelay): boolean {
			return value === OnLevelRelay.On;
		}
	}

	export const from =
	{
		Boolean(value: boolean): OnLevelRelay {
			return value ? OnLevelRelay.On : OnLevelRelay.Off;
		}
	}

}