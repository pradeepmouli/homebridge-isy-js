export enum RampRate {
	_90Minutes = 0,
	_80Minutes = 1,
	_70Minutes = 2,
	_60Minutes = 3,
	_50Minutes = 4,
	_45Minutes = 5,
	_40Minutes = 6,
	_35Minutes = 7,
	_30Minutes = 8,
	_25Minutes = 9,
	_20Minutes = 10,
	_15Minutes = 11,
	_10Minute = 12,
	_470Seconds = 13,
	_430Seconds = 14,
	_385Seconds = 15,
	_340Seconds = 16,
	_320Seconds = 17,
	_300Seconds = 18,
	_280Seconds = 19,
	_260Seconds = 20,
	_235Seconds = 21,
	_215Seconds = 22,
	_190Seconds = 23,
	_85Seconds = 24,
	_65Seconds = 25,
	_45Seconds = 26,
	_20Seconds = 27,
	_05Seconds = 28,
	_03Seconds = 29,
	_02Seconds = 30,
	_01Seconds = 31
}


export namespace RampRate {

	export const to = {
		seconds: toSeconds
	}
	export const from = {
		seconds: fromSeconds
	}
	export function fromSeconds(seconds: number): RampRate {
		if (seconds >= 90 * 60) {
			return RampRate._90Minutes;
		} else if (seconds >= 80 * 60) {
			return RampRate._80Minutes;
		} else if (seconds >= 70 * 60) {
			return RampRate._70Minutes;
		} else if (seconds >= 60 * 60) {
			return RampRate._60Minutes;
		} else if (seconds >= 50 * 60) {
			return RampRate._50Minutes;
		} else if (seconds >= 45 * 60) {
			return RampRate._45Minutes;
		} else if (seconds >= 40 * 60) {
			return RampRate._40Minutes;
		} else if (seconds >= 35 * 60) {
			return RampRate._35Minutes;
		} else if (seconds >= 30 * 60) {
			return RampRate._30Minutes;
		} else if (seconds >= 25 * 60) {
			return RampRate._25Minutes;
		} else if (seconds >= 20 * 60) {
			return RampRate._20Minutes;
		} else if (seconds >= 15 * 60) {
			return RampRate._15Minutes;
		} else if (seconds >= 10 * 60) {
			return RampRate._10Minute;
		} else if (seconds >= 470) {
			return RampRate._470Seconds;
		} else if (seconds >= 430) {
			return RampRate._430Seconds;
		} else if (seconds >= 385) {
			return RampRate._385Seconds;
		} else if (seconds >= 340) {
			return RampRate._340Seconds;
		} else if (seconds >= 320) {
			return RampRate._320Seconds;
		} else if (seconds >= 300) {
			return RampRate._300Seconds;
		} else if (seconds >= 280) {
			return RampRate._280Seconds;
		} else if (seconds >= 260) {
			return RampRate._260Seconds;
		} else if (seconds >= 235) {
			return RampRate._235Seconds;
		} else if (seconds >= 215) {
			return RampRate._215Seconds;
		}
	}
	export function toSeconds(rampRate: RampRate): number {
		switch (rampRate) {
			case RampRate._90Minutes:
				return 90 * 60;
			case RampRate._80Minutes:
				return 80 * 60;
			case RampRate._70Minutes:
				return 70 * 60;
			case RampRate._60Minutes:
				return 60 * 60;
			case RampRate._50Minutes:
				return 50 * 60;
			case RampRate._45Minutes:
				return 45 * 60;
			case RampRate._40Minutes:
				return 40 * 60;
			case RampRate._35Minutes:
				return 35 * 60;
			case RampRate._30Minutes:
				return 30 * 60;
			case RampRate._25Minutes:
				return 25 * 60;
			case RampRate._20Minutes:
				return 20 * 60;
			case RampRate._15Minutes:
				return 15 * 60;
			case RampRate._10Minute:
				return 10 * 60;
			case RampRate._470Seconds:
				return 470;
			case RampRate._430Seconds:
				return 430;
			case RampRate._385Seconds:
				return 385;
			case RampRate._340Seconds:
				return 340;
			case RampRate._320Seconds:
				return 320;
			case RampRate._300Seconds:
				return 300;
			case RampRate._280Seconds:
				return 280;
			case RampRate._260Seconds:
				return 260;
			case RampRate._235Seconds:
				return 235;
			case RampRate._215Seconds:
				return 215;
			case RampRate._190Seconds:
				return 190;
			case RampRate._85Seconds:
				return 85;
			case RampRate._65Seconds:
				return 65;
			case RampRate._45Seconds:
				return 45;
			case RampRate._20Seconds:
				return 20;

			case RampRate._05Seconds:
				return 5;
			case RampRate._03Seconds:
				return 3;

			case RampRate._02Seconds:
				return 2;
			case RampRate._01Seconds:
				return 1;
		}
	}

}
