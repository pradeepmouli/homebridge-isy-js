import { LeakSensor } from '../../../Devices/Insteon/index.js';

export enum Backlight {
	On0Off0 = 0,
	On1Off0 = 1,
	On2Off0 = 2,
	On3Off0 = 3,
	On4Off0 = 4,
	On5Off0 = 5,
	On6Off0 = 6,
	On7Off0 = 7,
	On8Off0 = 8,
	On9Off0 = 9,
	On10Off0 = 10,
	On11Off0 = 11,
	On12Off0 = 12,
	On13Off0 = 13,
	On14Off0 = 14,
	On15Off0 = 15,
	On0Off1 = 16,
	On1Off1 = 17,
	On2Off1 = 18,
	On3Off1 = 19,
	On4Off1 = 20,
	On5Off1 = 21,
	On6Off1 = 22,
	On7Off1 = 23,
	On8Off1 = 24,
	On9Off1 = 25,
	On10Off1 = 26,
	On11Off1 = 27,
	On12Off1 = 28,
	On13Off1 = 29,
	On14Off1 = 30,
	On15Off1 = 31,
	On0Off2 = 32,
	On1Off2 = 33,
	On2Off2 = 34,
	On3Off2 = 35,
	On4Off2 = 36,
	On5Off2 = 37,
	On6Off2 = 38,
	On7Off2 = 39,
	On8Off2 = 40,
	On9Off2 = 41,
	On10Off2 = 42,
	On11Off2 = 43,
	On12Off2 = 44,
	On13Off2 = 45,
	On14Off2 = 46,
	On15Off2 = 47,
	On0Off3 = 48,
	On1Off3 = 49,
	On2Off3 = 50,
	On3Off3 = 51,
	On4Off3 = 52,
	On5Off3 = 53,
	On6Off3 = 54,
	On7Off3 = 55,
	On8Off3 = 56,
	On9Off3 = 57,
	On10Off3 = 58,
	On11Off3 = 59,
	On12Off3 = 60,
	On13Off3 = 61,
	On14Off3 = 62,
	On15Off3 = 63,
	On0Off4 = 64,
	On1Off4 = 65,
	On2Off4 = 66,
	On3Off4 = 67,
	On4Off4 = 68,
	On5Off4 = 69,
	On6Off4 = 70,
	On7Off4 = 71,
	On8Off4 = 72,
	On9Off4 = 73,
	On10Off4 = 74,
	On11Off4 = 75,
	On12Off4 = 76,
	On13Off4 = 77,
	On14Off4 = 78,
	On15Off4 = 79,
	On0Off5 = 80,
	On1Off5 = 81,
	On2Off5 = 82,
	On3Off5 = 83,
	On4Off5 = 84,
	On5Off5 = 85,
	On6Off5 = 86,
	On7Off5 = 87,
	On8Off5 = 88,
	On9Off5 = 89,
	On10Off5 = 90,
	On11Off5 = 91,
	On12Off5 = 92,
	On13Off5 = 93,
	On14Off5 = 94,
	On15Off5 = 95,
	On0Off6 = 96,
	On1Off6 = 97,
	On2Off6 = 98,
	On3Off6 = 99,
	On4Off6 = 100,
	On5Off6 = 101,
	On6Off6 = 102,
	On7Off6 = 103,
	On8Off6 = 104,
	On9Off6 = 105,
	On10Off6 = 106,
	On11Off6 = 107,
	On12Off6 = 108,
	On13Off6 = 109,
	On14Off6 = 110,
	On15Off6 = 111,
	On0Off7 = 112,
	On1Off7 = 113,
	On2Off7 = 114,
	On3Off7 = 115,
	On4Off7 = 116,
	On5Off7 = 117,
	On6Off7 = 118,
	On7Off7 = 119,
	On8Off7 = 120,
	On9Off7 = 121,
	On10Off7 = 122,
	On11Off7 = 123,
	On12Off7 = 124,
	On13Off7 = 125,
	On14Off7 = 126,
	On15Off7 = 127
}

export namespace Backlight {
	export type Level = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15;

	export const getOnLevel = (backlight: Backlight): Level => {
		return (backlight & 0x0f) as Level;
	};

	export const getOffLevel = (backlight: Backlight): Level => {
		return ((backlight & 0xf0) >> 4) as Level;
	};
	export const to = {
		tuple: toTuple
	};

	export const from = {
		tuple: fromTuple
	};

	export function toTuple(backlight: Backlight): [Level, Level] {
		return [getOnLevel(backlight), getOffLevel(backlight)];
	}

	export function fromTuple(tuple: [Level, Level]): Backlight {
		return tuple[0] | (tuple[1] << 4);
	}
}
