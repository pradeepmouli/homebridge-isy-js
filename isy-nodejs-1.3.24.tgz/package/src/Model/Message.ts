import type { UnitOfMeasure } from '../ISY.js';

export interface Message<TEventInfo> {
	seqnum: number;
	sid: string;
	timestamp: string;
	control: string;
	action: string | number | { _: string | number; uom: UnitOfMeasure; prec: number };
	node: string;
	eventInfo: TEventInfo;
}
