export interface NodeNotes {
	isLoad: boolean;
	// #region Properties (2)
	location: string;
	spoken: string;
}
